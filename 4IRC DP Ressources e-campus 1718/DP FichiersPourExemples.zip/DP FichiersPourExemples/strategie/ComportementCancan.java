package tetepremiere.strategie;

public interface ComportementCancan {
	public void cancaner();
}
