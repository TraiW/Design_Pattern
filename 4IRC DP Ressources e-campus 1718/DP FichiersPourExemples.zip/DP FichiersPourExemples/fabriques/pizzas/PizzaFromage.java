package tetepremiere.fabrique.pizzas;

public class PizzaFromage extends Pizza {
	public PizzaFromage() {
		nom = "Pizza au fromage";
		pate = "pâte classique";
		sauce = "Sauce Marinara";
		garnitures.add("Mozzarella");
		garnitures.add("Parmesan");
	}
}
