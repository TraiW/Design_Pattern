package tetepremiere.fabrique.pizzas;

public class PizzaFruitsDeMer extends Pizza {
	public PizzaFruitsDeMer() {
		nom = "Pizza aux fruits de mer";
		pate = "pâte fine";
		sauce = "sauce à l'ail";
		garnitures.add("Moules");
		garnitures.add("Parmesan");
	}
}
