package tetepremiere.fabrique.pizzafm;

public class PizzaFromageStyleBrest extends Pizza {

	public PizzaFromageStyleBrest() { 
		nom = "Pizza style Brest et fromage";
		pate = "Pâte fine";
		sauce = "Sauce Marinara";
 
		garnitures.add("Reggiano");
		garnitures.add("Ail");
	}
}
