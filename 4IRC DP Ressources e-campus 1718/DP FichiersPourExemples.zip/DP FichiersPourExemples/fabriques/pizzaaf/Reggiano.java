package tetepremiere.fabrique.pizzaaf;

public class Reggiano implements Fromage {

	public String toString() {
		return "Reggiano";
	}
}
