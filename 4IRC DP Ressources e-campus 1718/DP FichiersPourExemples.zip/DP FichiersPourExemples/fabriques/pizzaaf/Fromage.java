package tetepremiere.fabrique.pizzaaf;

public interface Fromage {
	public String toString();
}
