package tetepremiere.fabrique.pizzaaf;

public class SauceMarinara implements Sauce {
	public String toString() {
		return "Sauce Marinara";
	}
}
