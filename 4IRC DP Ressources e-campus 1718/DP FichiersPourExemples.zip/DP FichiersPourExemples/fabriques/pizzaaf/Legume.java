package tetepremiere.fabrique.pizzaaf;

public interface Legume {
	public String toString();
}
