package tetepremiere.fabrique.pizzaaf;

public class Ail implements Legume {

	public String toString() {
		return "Ail";
	}
}
