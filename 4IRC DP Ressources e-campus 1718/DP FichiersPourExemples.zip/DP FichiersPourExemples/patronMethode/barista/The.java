package tetepremiere.patronmethode.barista;

public class The extends BoissonCafeinee {
	public void preparer() {
		System.out.println("Infusion du thé");
	}
	public void ajouterSupplements() {
		System.out.println("Ajout du citron");
	}
}
