package tetepremiere.patronmethode.barista;

public class Cafe extends BoissonCafeinee {
	public void preparer() {
		System.out.println("Passage du café");
	}
	public void ajouterSupplements() {
		System.out.println("Ajout du lait et du sucre");
	}
}
